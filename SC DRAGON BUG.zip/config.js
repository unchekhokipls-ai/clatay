module.exports = {
  BOT_TOKEN: "8942049020:AAHdtzlBSfbwlHoiRrVM8Gb7ycUjK6fD94Y",
  OWNER_IDS: ["5211633287"]
};
