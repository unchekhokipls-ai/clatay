FOTO SLIDESHOW X-SHADOW

photo1.png = slide 1
photo2.png = slide 2

index.js membaca kedua file ini dari folder ./photos/.
Tidak ada foto slide ke-3.
